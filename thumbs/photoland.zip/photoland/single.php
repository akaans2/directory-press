<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');

get_header(); ?>


  <div id="main">
  <div class="wrapper">      

    <h1><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>
    <div class="pagerbox"><p class="header"><span class="older"><?php previous_post_link('%link','< previous', FALSE); ?></span><span class="latest"><?php next_post_link('%link','next >', FALSE); ?></span></p></div>
    <div class="sep">&nbsp;</div>
      <div class="post post-single">
	<?php 
  wp_reset_query(); 
  if (have_posts()) : while (have_posts()) : the_post(); ?>


        <div class="content">
        <?php the_content(''); ?>
				<?php wp_link_pages(array('before' => '<p class="pages"><strong>'.__('Pages', 'wpzoom').':</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
        <?php if ($wpzoom_singlepost_cat == 'Show') { the_tags( '<p class="tags tabs">'.__('Tags', 'wpzoom').': ', ' ', '</p>'); } ?>
        <div class="cleaner">&nbsp;</div>
      <ul class="iconsSocial">
                    <li><?php _e('Bookmark this article', 'wpzoom');?>: </li>
                    <li><a href="http://twitter.com/share?url=<?php echo urlencode(the_permalink()); ?>&amp;text=<?php echo urlencode(the_title()); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/icons/ic_twitter.png" alt="Tweet This!" /></a></li>
                    <li><a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink();?>&amp;title=<?php the_title_attribute();?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/icons/ic_digg.png" alt="Digg it!" /></a></li>
                    <li><a href="http://del.icio.us/post?v=4&amp;noui&amp;jump=close&amp;url=<?php the_permalink();?>&amp;title=<?php the_title_attribute();?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/icons/ic_delicious.png" alt="Add to Delicious!" /></a></li>
                    <li><a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/icons/ic_facebook.png" alt="Share on Facebook!" /></a></li>
                    <li><a href="http://reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php the_title_attribute();?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/icons/ic_reddit.png" alt="Share on Reddit!" /></a></li>
                    <li><a href="http://www.stumbleupon.com/submit?url=<?php the_permalink(); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/icons/ic_stumbleupon.png" alt="Stumble it" /></a></li>
                    <li><a href="http://www.technorati.com/faves?add=<?php the_permalink(); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/icons/ic_technorati.png" alt="Add to Technorati Favorites" /></a></li>
                    <li class="last"><a href="<?php if (strlen($wpzoom_misc_feedburner) < 10) { bloginfo('rss2_url');} else {echo"$wpzoom_misc_feedburner";} ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/icons/ic_rss.png" alt="Subscribe by RSS" /></a></li>
                 </ul>
        <p class="tabs postmetadata"><?php if ($wpzoom_singlepost_cat == 'Show') { ?>Posted in: <span class="category"><?php the_category(' '); ?></span> | <?php } if ($wpzoom_singlepost_author == 'Show') { ?>by <?php the_author_posts_link(); ?> <?php } ?> | <?php if ($wpzoom_singlepost_date == 'Show') { ?><span class="datetime"> &mdash; <?php the_time("$dateformat \a\\t $timeformat"); ?></span> | <?php } ?><?php edit_post_link( __('Edit'), ' | ', ''); ?></p>
        </div>

      <?php endwhile; endif; ?>
      
      <?php comments_template(); ?>
      
    <div class="cleaner">&nbsp;</div>

      </div>

  </div> <!-- main-wrapper -->
	</div><!-- #main -->
<?php get_footer(); ?>