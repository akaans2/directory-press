<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$do_not_duplicate = array();

get_header();

		if(get_query_var('author_name')) :
		$curauth = get_userdatabylogin(get_query_var('author_name'));
		else :
		$curauth = get_userdata(get_query_var('author'));
		endif;
		?>

  <div id="main">
  <div class="wrapper">      

    <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	  <?php /* If this is a author archive */ if (is_author()) { ?>
		<h1 class="archive"><?php _e('Author Archive', 'wpzoom');?>: <a href="<?php echo $curauth->user_url; ?>"><?php echo $curauth->display_name; ?></a></h1>
 	  <?php } ?> 
    <div class="sep archive">&nbsp;</div>
    </div>

    <div class="mainWrapper" id="bgSwitch">
  
    <div class="wrapper">
  
      <?php include(TEMPLATEPATH . '/featured.php'); // calling slider section ?>
      
    </div>
    
    </div><!-- mainWrapper -->

    <div class="wrapper">
    
    <div class="pagerbox">
      <p><span class="older"><?php next_posts_link(__('&lt; older entries', 'wpzoom')); ?></span><span class="latest"><?php previous_posts_link(__('newer entries &gt;', 'wpzoom')); ?></span></p>
    </div>

    </div> <!-- wrapper -->
	</div><!-- #main -->

<?php get_footer(); ?>