<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}

get_header(); ?>



  <div id="main">

    <div class="mainWrapper" id="bgSwitch">
  
    <div class="wrapper">
  
      <?php include(TEMPLATEPATH . '/featured.php'); // calling slider section ?>
      
    </div>
    
    </div><!-- mainWrapper -->

    <div class="wrapper">
    
    <div class="pagerbox">
      <p><span class="older"><?php next_posts_link(__('&lt; older entries', 'wpzoom')); ?></span><span class="latest"><?php previous_posts_link(__('newer entries &gt;', 'wpzoom')); ?></span></p>
    </div>

    </div> <!-- wrapper -->
	</div><!-- #main -->
<?php get_footer(); ?>
