        <div id="featPosts">
       
  <?php
      
      $que = "";
      
      if (is_home())
      {

      $z = count($wpzoom_exclude_cats_home);
      if ($z > 0)
      {
        $x = 0;
        $que = "";
        while ($x < $z)
        {
          $que .= "-".$wpzoom_exclude_cats_home[$x];
          $x++;
          if ($x < $z) {$que .= ",";}
        }
      }
      
      query_posts($query_string . "&cat=$que");
      
      } // if is_home()
  
  
  while (have_posts()) : the_post();
  
 $i++;
 update_post_caches($posts);

unset($img);
if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
						$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
            $img = $thumbURL[0]; 
						}

            else {
                unset($img);
                if ($wpzoom_cf_use == 'Yes')
                {
                  $img = get_post_meta($post->ID, $wpzoom_cf_photo, true);
                }
                else
                {
                  if (!$img)
                  {
                    $img = catch_that_image($post->ID);
                  }
                }
              }

    if ($i == 1)
    {
    
    ?>


<div class="main_image">
    <?php if ($img) { $img = wpzoom_wpmu($img); ?><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=640&amp;w=960&amp;zc=1&amp;src=<?php echo $img ?>" alt="<?php the_title(); ?>" /><?php } else
    { ?><img src="<?php bloginfo('template_directory'); ?>/images/no-photo.png" alt="<?php the_title(); ?>" width="960" height="640" /><?php } ?>
    <div class="desc">
        <a href="##" class="collapse">Close Me!</a>
        <div class="block">
            <h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
            <small><?php the_time("$dateformat"); ?></small>
            <p><?php the_content_limit(160, ''); ?></p>
        </div>
    </div>
</div>

<div class="image_thumb">
    <ul>

        <li>
            
            <?php if ($img) { $img = wpzoom_wpmu($img); ?><a href="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=640&amp;w=960&amp;zc=1&amp;src=<?php echo $img ?>"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=45&amp;w=60&amp;zc=1&amp;src=<?php echo $img ?>" alt="<?php the_title(); ?>" /></a><?php } 
            else { // show ?>
            <a href="<?php bloginfo('template_directory'); ?>/images/no-photo.png"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=45&amp;w=60&amp;zc=1&amp;src=<?php bloginfo('template_directory'); ?>/images/no-photo-s.png" alt="<?php the_title(); ?>" /></a>
            <?php } ?>
            <div class="block">
                <h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                <small><?php the_time("$dateformat"); ?></small>
                <p><?php the_content_limit(160, ''); ?></p>
            </div>
        </li>
        <?php } // if $i == 1
        elseif ($i > 1){
 ?>

        <li>
            
            <?php if ($img) { $img = wpzoom_wpmu($img); ?><a href="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=640&amp;w=960&amp;zc=1&amp;src=<?php echo $img ?>"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=45&amp;w=60&amp;zc=1&amp;src=<?php echo $img ?>" alt="<?php the_title(); ?>" /></a><?php } 
            else { // show ?>
            <a href="<?php bloginfo('template_directory'); ?>/images/no-photo.png"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=45&amp;w=60&amp;zc=1&amp;src=<?php bloginfo('template_directory'); ?>/images/no-photo-s.png" alt="<?php the_title(); ?>" /></a>
            <?php } ?>
            
            <div class="block">
                <h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                <small><?php the_time("$dateformat"); ?></small>
                <p><?php the_content_limit(160, ''); ?></p>
            </div>
        </li>
        
        <?php } // elseif $i > 1 ?>

<?php endwhile; ?>

    <?php if ($i > 0) { ?></ul><div class="cleaner cleaner-spec">&nbsp;</div></div><?php } ?>
        
        </div><!-- end #featPosts -->

      <?php include(TEMPLATEPATH . '/bgpick.php'); // calling slider section ?>

      <div class="cleaner">&nbsp;</div>