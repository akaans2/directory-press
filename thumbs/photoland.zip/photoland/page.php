<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');

get_header(); ?>


  <div id="main">
  <div class="wrapper">      

    <h1><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>
    <div class="pagerbox"><p class="header"><span class="older"><?php previous_post_link('%link','< previous', FALSE); ?></span><span class="latest"><?php next_post_link('%link','next >', FALSE); ?></span></p></div>
    <div class="sep">&nbsp;</div>
      <div class="post post-single">
	<?php 
  wp_reset_query(); 
  if (have_posts()) : while (have_posts()) : the_post(); ?>

        <div class="content">
        <?php the_content(''); ?>
				<?php wp_link_pages(array('before' => '<p class="pages"><strong>'.__('Pages', 'wpzoom').':</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
        <?php edit_post_link( __('EDIT', 'wpzoom'), '', ''); ?>
        </div>

      <?php endwhile; endif; ?>
      


      <?php comments_template(); ?>
      
    <div class="cleaner">&nbsp;</div>

      </div>

  </div> <!-- main-wrapper -->
	</div><!-- #main -->
<?php get_footer(); ?>