<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php if ($wpzoom_seo_enable == 'Enable') { wpzoom_titles(); } else { wp_title('-'); echo ' | '; bloginfo('name'); } ?></title>
<meta http-equiv="content-type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php if ($wpzoom_seo_enable == 'Enable') { 
if (is_single() || is_page() ) : if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<meta name="description" content="<?php echo strip_tags(get_the_excerpt()); ?>" />
<?php meta_post_keywords(); ?>
<?php endwhile; endif; elseif(is_home()) : ?>
<meta name="description" content="<?php if (strlen($wpzoom_meta_desc) < 1) { bloginfo('description');} else {echo"$wpzoom_meta_desc";}?>" />
<?php meta_home_keywords(); ?>
<?php endif; ?>
<?php wpzoom_index(); ?>
<?php wpzoom_canonical(); } ?>
<?php if (strlen($wpzoom_misc_favicon) > 1 ) { ?><link rel="shortcut icon" href="<?php echo "$wpzoom_misc_favicon";?>" type="image/x-icon" /><?php } ?>

<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/custom.css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url');?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_enqueue_script('jquery');  ?>
<?php wp_head(); ?>
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.slider.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/effects.js" type="text/javascript"></script> 
<?php
if ($wpzoom_cufon_enable == 'Yes')
{
$wpzoom_cufon_font = strtolower($wpzoom_cufon_font);
?>
<script src="<?php bloginfo('template_directory'); ?>/js/cufon.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/fonts/<?php echo"$wpzoom_cufon_font"; ?>.font.js" type="text/javascript"></script>
<script type="text/javascript">
  Cufon.replace('#ftWidgets p.header, .pagerbox p, h1, .post-single h2, .post-single h3, .post-single h4', {
  hover: { color: '#f62f94' },
  fontFamily: '<?php echo"$wpzoom_cufon_font"; ?>'});
</script>
<?php
} // if Cufon is enabled in Options Page
?>
</head>

<body>
<div id="container">

  <div id="header">
    <div class="wrapper">
      <div id="logo"><a href="<?php echo get_option('home'); ?>"><?php if ($wpzoom_misc_logo_path) { ?><img src="<?php echo "$wpzoom_misc_logo_path";?>" alt="<?php bloginfo('name'); ?>" /><?php } else { ?><img src="<?php bloginfo('template_directory'); ?>/images/logo.png" alt="<?php bloginfo('name'); ?>" /><?php } ?></a></div><!-- end #logo -->
      <div class="sep">&nbsp;</div>
    </div><!-- end .wrapper -->
  </div><!-- end #header -->
  
  <div class="cleaner">&nbsp;</div>