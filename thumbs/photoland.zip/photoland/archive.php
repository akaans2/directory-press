<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$do_not_duplicate = array();

get_header(); ?>





  <div id="main">
  <div class="wrapper">      

    <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	  <?php /* If this is a category archive */ if (is_category()) { ?>
		<h1 class="archive"><?php single_cat_title(); ?></h1>
 	  <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
		<h1 class="archive"><?php _e('Archive for', 'wpzoom');?>: <?php single_tag_title(); ?></h1>
 	  <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
		<h1 class="archive"><?php _e('Archive for', 'wpzoom');?> <?php the_time('F jS, Y'); ?></h1>
 	  <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		<h1 class="archive"><?php _e('Archive for', 'wpzoom');?> <?php the_time('F, Y'); ?></h1>
 	  <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		<h1 class="archive"><?php _e('Archive for', 'wpzoom');?> <?php the_time('Y'); ?></h1>
	  <?php /* If this is an author archive */ } ?> 
    <div class="sep archive">&nbsp;</div>
  </div>

    <div class="mainWrapper" id="bgSwitch">
  
    <div class="wrapper">
  
      <?php include(TEMPLATEPATH . '/featured.php'); // calling slider section ?>
      
    </div>
    
    </div><!-- mainWrapper -->

    <div class="wrapper">
    
    <div class="pagerbox">
      <p><span class="older"><?php next_posts_link(__('&lt; older entries', 'wpzoom')); ?></span><span class="latest"><?php previous_posts_link(__('newer entries &gt;', 'wpzoom')); ?></span></p>
    </div>

    </div> <!-- wrapper -->
	</div><!-- #main -->

<?php get_footer(); ?>
