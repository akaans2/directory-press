<?php
/*
Template Name: Blog Archives
*/
?>
<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
$dateformat = get_option('date_format');
$timeformat = get_option('time_format'); 

get_header(); ?>




  <div id="main">
  <div class="wrapper">      

    <h1 class="archive"><?php the_title(); ?></h1>
    <div class="sep archive">&nbsp;</div>

			
				<div class="content post post-single">
        <h2 class="archive"><?php _e('The Last 20 Posts', 'wpzoom');?></h2>
        <div class="sep">&nbsp;</div>
        <ul class="archive">
					<?php query_posts('showposts=20'); ?>
					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
          <li>
					<?php $wp_query->is_home = false; ?>

<?php unset($img);
if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
						$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
            $img = $thumbURL[0]; 
						}

            else {
                unset($img);
                if ($wpzoom_cf_use == 'Yes')
                {
                  $img = get_post_meta($post->ID, $wpzoom_cf_photo, true);
                }
                else
                {
                  if (!$img)
                  {
                    $img = catch_that_image($post->ID);
                  }
                }
              }

         if ($img){ 
         $img = wpzoom_wpmu($img);
         ?>
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=60&amp;w=90&amp;zc=1&amp;src=<?php echo $img ?>" alt="<?php the_title(); ?>" /></a><?php } 
            else { // show ?>
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=60&amp;w=90&amp;zc=1&amp;src=<?php bloginfo('template_directory'); ?>/images/no-photo-s.png" alt="<?php the_title(); ?>" /></a>
            <?php } ?>

            <div class="block">
                <h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                <p><?php the_content_limit(200, ''); ?></p>
            </div>
            <div class="sep">&nbsp;</div>
            </li>
					<?php endwhile; endif; ?>	
				</ul>	

        <h2 class="archive"><?php _e('Categories', 'wpzoom');?></h2>
				<ul>
					<?php wp_list_categories('title_li=&hierarchical=0&show_count=1'); ?>	
				</ul>	

        <h2 class="archive"><?php _e('Monthly Archives', 'wpzoom');?></h2>
        <ul>
					<?php wp_get_archives('type=monthly&show_post_count=1'); ?>	
				</ul>
				</div>

    <div class="cleaner">&nbsp;</div>
      
  </div> <!-- main-wrapper -->
	</div><!-- #main -->

<?php get_footer(); ?>