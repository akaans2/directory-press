<?php
define("INC", TEMPLATEPATH . "/functions");

require_once INC . "/wpzoom-functions.php";
require_once INC . "/wpzoom-core.php";

?>