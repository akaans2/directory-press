    function SetBG(color)
    {
        var elm=document.getElementById('bgSwitch');
        elm.style.backgroundColor = color;
    }   
   function doTogleBG(){
    if (BGflag) {
        BGflag = false;
//        var elm=document.getElementById('bgcol');
//        elm.style.display="none";
//        elm.style.visibility="hidden";
    SetBG('#FFFFFF');
    }else{
        BGflag = true;
//        var elm=document.getElementById('bgcol');
//        elm.style.display="";
//        elm.style.visibility="visible";
        SetBG('#000000')
    }
    return false;
   }