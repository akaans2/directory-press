<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$dateformat = get_option('date_format');
$timeformat = get_option('time_format'); 

get_header(); ?>

<div id="posts">

<?php
		if(get_query_var('author_name')) :
		$curauth = get_userdatabylogin(get_query_var('author_name'));
		else :
		$curauth = get_userdata(get_query_var('author'));
		endif;
?>

<?php include(TEMPLATEPATH . '/wpzoom_recent_posts.php'); ?>

		<div class="sep">&nbsp;</div>
</div><!-- end main wrapper -->
</div><!-- end #main -->
</div>
<?php get_footer(); ?>
