 	  <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	  <?php if (is_category()) { ?>
		<h1><?php _e('Archive for the', 'wpzoom');?> &#8216;<?php single_cat_title(); ?>&#8217; <?php _e('Category', 'wpzoom');?></h1>
 	  <?php } elseif( is_tag() ) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?>: <?php single_tag_title(); ?></h1>
 	  <?php } elseif (is_day()) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?> <?php the_time('F jS, Y'); ?></h1>
 	  <?php } elseif (is_month()) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?> <?php the_time('F, Y'); ?></h1>
 	  <?php } elseif (is_year()) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?> <?php the_time('Y'); ?></h1>
	  <?php } ?>
 	  <?php if (is_author()) { ?>
		<h1 class="pagetitle"><?php _e('Author Archive', 'wpzoom');?>: <a href="<?php echo $curauth->user_url; ?>"><?php echo $curauth->display_name; ?></a></h1>
 	  <?php } ?>
 	  <?php if (is_search()) { ?>
		<h1 class="pagetitle"><?php _e('Search Results for', 'wpzoom');?>: <?php the_search_query(); ?></h1>
 	  <?php } ?>

<?php wp_reset_query(); ?>

<?php
if (is_home()) {
$z = count($wpzoom_exclude_cats_home);
      if ($z > 0)
      {
        $x = 0;
        $que = "";
        while ($x < $z)
        {
          $que .= "-".$wpzoom_exclude_cats_home[$x];
          $x++;
          if ($x < $z) {$que .= ",";}
        }
      }
      
      query_posts($query_string . "&cat=$que");
}
 ?>

<?php if (have_posts()) : ?>

<?php
if ($wpzoom_ppr == 2)
{
  $listClass = 'posts-2';
  $imgParams = 'h=280&amp;w=455';
}
elseif ($wpzoom_ppr == 3)
{
  $listClass = 'posts-3';
  $imgParams = 'h=180&amp;w=290';
}
elseif ($wpzoom_ppr == 4)
{
  $listClass = 'posts-4';
  $imgParams = 'h=135&amp;w=215';
} 
elseif ($wpzoom_ppr == 5)
{
  $listClass = 'posts-5';
  $imgParams = 'h=105&amp;w=170';
}
elseif ($wpzoom_ppr == 6)
{
  $listClass = 'posts-6';
  $imgParams = 'h=90&amp;w=140';
} 
?>

<ul class="posts <?php echo"$listClass"; ?>">
<?php 
    while (have_posts()) : the_post();
    $i++;
?>
  <li class="post<?php if ($i == $wpzoom_ppr) {$i=0; echo " post-last"; $sep = TRUE; } else {$sep = FALSE;} ?>">
    <?php unset($img);
if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
						$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
            $img = $thumbURL[0]; 
						}

            else {
                unset($img);
                if ($wpzoom_cf_use == 'Yes')
                {
                  $img = get_post_meta($post->ID, $wpzoom_cf_photo, true);
                }
                else
                {
                  if (!$img)
                  {
                    $img = catch_that_image($post->ID);
                  }
                }
              }

         if ($img){ 
         $img = wpzoom_wpmu($img);
         ?>
        <div class="cover"><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $img ?>&amp;<?php echo $imgParams; ?>&amp;zc=1" alt="<?php the_title(); ?>" class="bordered" /></a></div><?php } ?>
    <h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
    <?php the_excerpt(); ?>   
    <p class="postmetadata"><span class="category"><?php the_category(', '); ?></span> | <span class="timestamp"><?php the_time("$dateformat"); ?></span> | <a href="<?php the_permalink() ?>#commentspost" title="Jump to the comments" rel="nofollow"><?php comments_number(__('no comments', 'wpzoom'),__('1 comment', 'wpzoom'),__('% comments', 'wpzoom')); ?></a> <?php edit_post_link(' | EDIT','',''); ?></p>   
  </li>
  <?php if ($sep) {echo"<li class=\"sep\">&nbsp;</li>";} ?>

<?php endwhile; ?>
            <?php else : ?>
            
            <h3><?php _e('There are no posts in this category', 'wpzoom'); ?></h3>
            
            <?php endif; ?>

    <div class="navigation pagerbox">
			<?php next_posts_link(__('&laquo; Older Entries', 'wpzoom')); ?>
      <?php previous_posts_link(__('Newer Entries &raquo;', 'wpzoom')); ?>
		</div>