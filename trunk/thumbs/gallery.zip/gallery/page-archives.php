<?php
/*
Template Name: Blog Archives
*/
?>
<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');
$do_not_duplicate = array();
?>
<?php get_header(); ?>
<div id="single">
<div class="post post-single">
				<h2 class="title"><?php _e('The Last 20 Posts', 'wpzoom');?></h2>
			
				<ul>
					<?php query_posts('showposts=20'); ?>
					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<?php $wp_query->is_home = false; ?>
					<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a> | <?php the_time("$dateformat $timeformat"); ?> | <span class="comments"><?php _e('Comments', 'wpzoom');?> (<?php echo $post->comment_count ?>)</span></li>
					<?php endwhile; endif; ?>	
				</ul>				
			
				<h2 class="title"><?php _e('Categories', 'wpzoom');?></h2>
				<ul>
					<?php wp_list_categories('title_li=&hierarchical=0&show_count=1'); ?>	
				</ul>	
					
				<h2 class="title"><?php _e('Monthly Archives', 'wpzoom');?></h2>
				<ul>
					<?php wp_get_archives('type=monthly&show_post_count=1'); ?>	
				</ul>

		<div class="sep">&nbsp;</div>
</div><!-- end #single -->
</div>
</div><!-- end .wrapper -->
</div><!-- end .#main -->
<?php get_footer(); ?>
