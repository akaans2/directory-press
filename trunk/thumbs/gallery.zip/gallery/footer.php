<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
?>
  <div id="footer">
    <div class="wrapper">
      <div id="sidebar-narrow">
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar: Bottom Narrow') ) : ?> <?php endif; ?>
        <div class="cleaner">&nbsp;</div>
      </div><!-- sidebar narrow -->
      <div id="sidebar-wide">
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar: Bottom Wide') ) : ?> <?php endif; ?>
      </div><!-- sidebar wide -->
      <p>Copyright &copy; <?php echo date("Y",time()); ?> <?php bloginfo('name'); ?>. All rights reserved.<br /><a href="http://www.wpzoom.com/themes/gallery/">GALLERY Theme</a> by <a href="http://www.wpzoom.com/">WPZOOM</a></p>
    </div>
  <div class="cleaner">&nbsp;</div>
  </div><!-- end #footer -->
</div><!-- end #container -->
		<?php wp_footer(); ?>
<?php if ($wpzoom_misc_analytics != '' && $wpzoom_misc_analytics_select == 'Yes')
{
  echo stripslashes($wpzoom_misc_analytics);
} ?>
</body>
</html>
