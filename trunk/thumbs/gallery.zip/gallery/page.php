<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
?> 
<?php get_header(); ?>

<div id="single">
  <div class="post post-single">

		<?php 
  wp_reset_query(); 
  if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div id="post-<?php the_ID(); ?>">
		<?php 
         $photo = get_post_meta($post->ID, 'photo', true); 
         if ($photo) : ?> 
          <div class="photo-post"><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $photo ?>&amp;h=300&amp;w=600&amp;zc=1" alt="<?php the_title(); ?>" class="preview" /></a></div>
          <?php endif; ?>
    <h1><?php the_title(); ?></h1>
    <p class="postmetadata"><?php edit_post_link('EDIT','','.'); ?></p>
        <?php the_content(''); ?>
        <?php wp_link_pages(array('before' => '<p class="pages"><strong>'.__('Pages', 'wpzoom').':</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
		</div>
		<div class="cleaner">&nbsp;</div>
		<?php endwhile; endif; ?>
	</div>
</div><!-- end of #single -->
<?php get_sidebar(); ?>
<div class="post-comments">
    <div id="tabspost">
  	<?php comments_template(); ?>
    </div>

</div>

		<div class="sep">&nbsp;</div>
</div><!-- end main wrapper -->
</div><!-- end #main -->
<?php get_footer(); ?>