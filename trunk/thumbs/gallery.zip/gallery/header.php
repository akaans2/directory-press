<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
$activestyle = strtolower($wpzoom_theme_style); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php if ($wpzoom_seo_enable == 'Enable') { wpzoom_titles(); } else { wp_title('-'); echo ' | '; bloginfo('name'); } ?></title>
<meta http-equiv="content-type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php if ($wpzoom_seo_enable == 'Enable') { 
if (is_single() || is_page() ) : if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<meta name="description" content="<?php echo strip_tags(get_the_excerpt()); ?>" />
<?php meta_post_keywords(); ?>
<?php endwhile; endif; elseif(is_home()) : ?>
<meta name="description" content="<?php if (strlen($wpzoom_meta_desc) < 1) { bloginfo('description');} else {echo"$wpzoom_meta_desc";}?>" />
<?php meta_home_keywords(); ?>
<?php endif; ?>
<?php wpzoom_index(); ?>
<?php wpzoom_canonical(); } ?>
<?php if (strlen($wpzoom_misc_favicon) > 1 ) { ?><link rel="shortcut icon" href="<?php echo "$wpzoom_misc_favicon";?>" type="image/x-icon" /><?php } ?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/styles/style_<?php echo"$activestyle";?>.css" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/dropdown.css" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/custom.css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php if (strlen($wpzoom_misc_feedburner) < 10) { bloginfo('rss2_url');} else {echo"$wpzoom_misc_feedburner";} ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_enqueue_script('jquery'); ?>
<?php wp_head(); ?>
<script src="<?php bloginfo('template_directory'); ?>/js/dropdown.js" type="text/javascript"></script>
</head>

<body>
<div id="container">
  <div id="header">
    <div class="wrapper">
      <div id="logo"><a href="<?php echo get_option('home'); ?>"><?php if ($wpzoom_misc_logo_path) { ?><img src="<?php echo "$wpzoom_misc_logo_path";?>" alt="<?php bloginfo('name'); ?>" /><?php } else { ?><img src="<?php bloginfo('template_directory'); ?>/images/logo_<?php echo"$activestyle";?>.png" alt="<?php bloginfo('name'); ?>" /><?php } ?></a></div>
      <?php if (strlen($wpzoom_ad_head_imgpath) > 0) {?>
      <div id="bannerHead"><?php if (strlen($wpzoom_ad_head_url) > 1) {?><a href="<?php echo "$wpzoom_ad_head_url";?>" target="_blank" rel="external<?php if ($wpzoom_ad_banner_nofollow == 'Yes') { echo",nofollow"; }?>"><img src="<?php echo "$wpzoom_ad_head_imgpath";?>" alt="" /></a><?php } else { ?><img src="<?php echo "$wpzoom_ad_head_imgpath";?>" alt="" /><?php }?></div>
      <?php } ?>


  <div id="navigation">
    <img src="<?php bloginfo('template_directory'); ?>/images/back_cats_left.png" width="10" height="30" alt="" class="left" />
    <img src="<?php bloginfo('template_directory'); ?>/images/back_cats_right.png" width="11" height="30" alt="" class="right" />


      <div id="headRSS">
        <p><a href="<?php if (strlen($wpzoom_misc_feedburner) < 10) { bloginfo('rss2_url');} else {echo"$wpzoom_misc_feedburner";} ?>"><img src="<?php bloginfo('template_directory'); ?>/images/icon_rss.png" alt="Subscribe to RSS" width="16" height="16" /><?php _e('Subscribe to RSS');?></a></p>
      </div>
      <div id="search"> 
      <form method="get" id="searchformtop" action="<?php echo get_option('home'); ?>">
       <input type="text" name="s" id="setop" onblur="if (this.value == '') {this.value = '<?php _e('search', 'wpzoom');?>';}" onfocus="if (this.value == '<?php _e('search', 'wpzoom');?>') {this.value = '';}" value="<?php _e('search', 'wpzoom');?>" class="text" />
       <input type="submit" id="searchsubmittop" class="submit" value="<?php _e('search', 'wpzoom');?>" />
      </form>  
      </div><!-- end #search -->
      
      <div id="menu" class="dropdown">
      <?php $menu = wp_nav_menu(array('container' => '','container_class' => '','menu_class' => 'home','menu_id' => 'nav','echo' => false,'sort_column' =>'menu_order','theme_location' =>'primary'));print $menu; ?>
      </div>

  </div><!-- end #navigation -->

    </div><!-- end of .wrapper -->
  </div><!-- end of #header -->
  <div id="main">
  <div class="wrapper">