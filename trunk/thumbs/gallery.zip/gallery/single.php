<?php get_header(); ?>
<?php
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
wp_reset_query();
$dateformat = get_option('date_format');
$timeformat = get_option('time_format'); 

if (have_posts()) : while (have_posts()) : the_post(); ?>

<div id="single">
  <div class="post post-single">
		<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
			
      <?php if (strlen($wpzoom_ad_content_imgpath) > 1 && $wpzoom_ad_content_select == 'Yes' && $wpzoom_ad_content_pos == 'Before') { echo '<div class="sep">&nbsp;</div><div class="banner">'.stripslashes($wpzoom_ad_content_imgpath)."</div>"; }?>      
      <h1><?php the_title(); ?></h1>
      <p class="tabs postmetadata"><?php if ($wpzoom_singlepost_cat == 'Show') { _e('in', 'wpzoom');?> <span class="category"><?php the_category(' '); ?></span> <?php } if ($wpzoom_singlepost_author == 'Show') { _e('by', 'wpzoom');?> <?php the_author_posts_link();  } if ($wpzoom_singlepost_date == 'Show') { ?><span class="datetime"> &mdash; <?php the_time("$dateformat $timeformat"); ?></span> | <?php } ?><a href="<?php the_permalink() ?>#commentspost" title="Jump to the comments"><?php comments_number(__('no comments', 'wpzoom'),__('1 comment', 'wpzoom'),__('% comments', 'wpzoom')); ?></a><?php edit_post_link( __('Edit'), ' | ', ''); ?></p>
				<div class="sep">&nbsp;</div>
        <?php the_content(''); ?>
				<?php wp_link_pages(array('before' => '<p><strong>'.__('Pages', 'wpzoom').':</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
        <?php if ($wpzoom_singlepost_cat == 'Show') { the_tags( '<p class="tags tabs">'.__('Tags', 'wpzoom').': ', ' ', '</p>'); } ?>
				<?php if ($wpzoom_authors_show == 'Yes') {?>
        <div class="postauthor">
        <div class="avatar"><?php echo get_avatar( get_the_author_id() , 60 ); ?></div>
        <p class="more"><?php _e('More posts by', 'wpzoom');?> <?php the_author_posts_link(); ?> &raquo;</p>
        <h6><?php _e('Author', 'wpzoom');?>: <a href="<?php the_author_url(); ?>"><?php the_author_firstname(); the_author_lastname(); ?></a></h6>
        <p><?php the_author_description(); ?></p>
        <div class="cleaner">&nbsp;</div>
        </div>
        <?php } ?>
				<div class="sep">&nbsp;</div>
        <div class="share">
                 <ul>
                    <li><a href="http://twitter.com/share?url=<?php echo urlencode(the_permalink()); ?>&amp;text=<?php echo urlencode(the_title()); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/i_twitter.png" alt="Tweet This!" /><?php _e('Tweet This', 'wpzoom');?></a></li>
                    <li><a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink();?>&amp;title=<?php the_title();?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/i_digg.png" alt="Digg it!" /><?php _e('Digg This', 'wpzoom');?></a></li>
                    <li><a href="http://del.icio.us/post?v=4&amp;noui&amp;jump=close&amp;url=<?php the_permalink();?>&amp;title=<?php the_title();?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/i_delicious.png" alt="Add to Delicious!" /><?php _e('Save to delicious', 'wpzoom');?></a></li>
                    <li><a href="http://www.stumbleupon.com/submit?url=<?php the_permalink(); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/i_stumble.png" alt="Stumble it" /><?php _e('Stumble it', 'wpzoom');?></a></li>
                    <li><a href="<?php if (strlen($wpzoom_misc_feedburner) < 10) { bloginfo('rss2_url');} else {echo"$wpzoom_misc_feedburner";} ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/i_feed.png" alt="Subscribe by RSS" /><?php _e('RSS Feed', 'wpzoom');?></a></li>
                 </ul>
        </div>
      <div class="cleaner">&nbsp;</div>
      <?php if (strlen($wpzoom_ad_content_imgpath) > 1 && $wpzoom_ad_content_select == 'Yes' && $wpzoom_ad_content_pos == 'After') { echo '<div class="sep">&nbsp;</div><div class="banner">'.stripslashes($wpzoom_ad_content_imgpath)."</div>"; }?>
      <div class="sep">&nbsp;</div>

<?php if ($wpzoom_comments_pos == 'Narrow') { ?>
<div class="post-comments">
    <div id="tabspost">
  	<?php comments_template(); ?>
    </div>
</div> <!-- end .post-comments -->
<?php } ?>

		</div>
	</div>
</div><!-- end of #single -->
<?php get_sidebar(); ?>
<?php if ($wpzoom_comments_pos != 'Narrow') { ?>
<div class="post-comments">
    <div id="tabspost">
  	<?php comments_template(); ?>
    </div>
</div> <!-- end .post-comments -->
<?php } ?>
	<?php endwhile; else: ?>

		<p><?php _e('Sorry, no posts matched your criteria', 'wpzoom');?>.</p>
<?php endif; ?>
		<div class="sep">&nbsp;</div>
</div><!-- end main wrapper -->
</div><!-- end #main -->
<?php get_footer(); ?>