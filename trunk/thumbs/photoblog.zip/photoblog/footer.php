<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
?>
  </div> <!-- .wrapper -->

  <div class="cleaner">&nbsp;</div>
	</div><!-- #main -->
  <div id="footer">
    <div class="wrapper">
      <p class="wpzoom"><a href="http://www.wpzoom.com" target="_blank"><?php _e('Photoblog WordPress Theme', 'wpzoom'); ?></a> <?php _e('by', 'wpzoom'); ?> <a href="http://www.wpzoom.com" target="_blank" title="Photoblog WordPress Themes"><img src="<?php bloginfo('template_directory'); ?>/images/wpzoom.png" alt="WPZOOM" /></a></p>
      <p class="copy"><?php _e('Copyright', 'wpzoom'); ?> &copy; <?php echo date("Y",time()); ?> <?php bloginfo('name'); ?>. <?php _e('All Rights Reserved', 'wpzoom'); ?>.</p>
    </div>
  </div><!-- end #footer -->
</div><!-- end #container -->
<?php wp_footer(); ?>
<?php if ($wpzoom_misc_analytics != '' && $wpzoom_misc_analytics_select == 'Yes')
{
  echo stripslashes($wpzoom_misc_analytics);
} ?>
</body>
</html>