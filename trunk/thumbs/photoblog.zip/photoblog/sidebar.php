<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
?>
      <div id="side">
      <?php if (strlen($wpzoom_ad_side_imgpath) > 1 && $wpzoom_ad_side_select == 'Yes' && $wpzoom_ad_side_pos == 'Before') { echo '<div class="banner">'.stripslashes($wpzoom_ad_side_imgpath)."</div>"; }?>
      <div class="sidebar-wide-top">
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar: Top Wide') ) : ?> <?php endif; ?>
      </div><!-- sidebar wide -->

      <?php if (strlen($wpzoom_ad_side_imgpath) > 1 && $wpzoom_ad_side_select == 'Yes' && $wpzoom_ad_side_pos == 'After') { echo '<div class="banner">'.stripslashes($wpzoom_ad_side_imgpath)."</div>"; }?>
      </div><!-- End of #side -->