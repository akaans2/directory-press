<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');
?>
<?php get_header(); ?>

        <div id="content">
          <div id="posts">

		<?php

  if (have_posts()) : ?>
 	  <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
<div class="block post">
      <div class="frame">
 	  <?php /* If this is a category archive */ if (is_category()) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?>: <?php single_cat_title(); ?></h1>
 	  <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?>: <?php single_tag_title(); ?></h1>
 	  <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?> <?php the_time('F jS, Y'); ?></h1>
 	  <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?> <?php the_time('F, Y'); ?></h1>
 	  <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		<h1 class="pagetitle"><?php _e('Archive for', 'wpzoom');?> <?php the_time('Y'); ?></h1>
	  <?php } ?>
</div>
</div>

<?php include(TEMPLATEPATH . '/wpzoom_recent_posts.php'); ?>

	<?php else : ?>
<div class="block post">
      <div class="frame">
    <?php 
    if ( is_category() ) {
    ?>
    <h1 class="pagetitle"><?php _e('No posts', 'wpzoom');?></h1>
    <?php } 
		if ( is_category() ) { // If this is a category archive
			printf('<p>'.__('Sorry, but there aren\'t any posts in the %s category yet.', 'wpzoom').'</p>', single_cat_title('',false));
		} elseif ( is_date() ) { // If this is a date archive
			echo('<p>'.__('Sorry, but there aren\'t any posts with this date.', 'wpzoom').'</p>');
		} else {
			echo('<p>'.__('No posts found.', 'wpzoom').'</p>');
		}

echo"</div></div>";
	endif;
?>
          </div><!-- end #posts -->
        </div><!-- end #content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>