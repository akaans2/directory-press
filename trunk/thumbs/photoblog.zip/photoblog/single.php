<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');
$do_not_duplicate = array();

$type = get_post_meta($post->ID, "type", true);

$showsidebar = TRUE;
if ($type == 'wide')
{
  $addclass = " class=\"content-wide\"";
  $showsidebar = FALSE;
}
elseif ($type == 'leftsidebar')
{
  $addclass = " class=\"leftSidebar\"";
}

?>
<?php get_header(); ?>

        <div id="content"<?php echo"$addclass"; ?>>

          <div id="single" class="singleP">

      <div class="block post">
      <div class="frame">
      <?php 
  wp_reset_query(); 
  if (have_posts()) : while (have_posts()) : the_post(); ?>

      <?php if (strlen($wpzoom_ad_content_imgpath) > 1 && $wpzoom_ad_content_select == 'Yes' && $wpzoom_ad_content_pos == 'Before') { echo '<div class="banner">'.stripslashes($wpzoom_ad_content_imgpath)."</div>"; }?>      
      <?php 
         $photo = get_post_meta($post->ID, "$wpzoom_cf_photo", true);

        $sizes = $wpzoom_sizes_array;

        ?>  
      <div class="inside">
      <h1><?php the_title(); ?></h1>
      <p class="postmetadata"><span class="category"><?php the_category(', '); ?></span><span class="datetime"> &mdash; <?php the_time("$dateformat $timeformat"); ?></span> | <a href="<?php the_permalink() ?>#commentspost" title="Jump to the comments"><?php comments_number(__('no comments', 'wpzoom'),__('1 comment', 'wpzoom'),__('% comments', 'wpzoom')); ?></a> | <?php edit_post_link(' Edit this entry','','.'); ?></p>
				<div class="sep">&nbsp;</div>
        <?php if ($photo) { 
        if ($wpzoom_sizes_show == 'Yes')
        {
        ?>
        <div class="sizes"><ul>
        <li class="title"><?php _e('other sizes', 'wpzoom');?>:</li><?
        foreach ($sizes as $key => $size)
        {
          $vals = explode("x",$size);
          ?><li><a href="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $photo; ?>&amp;<?php echo"h=$vals[1]&amp;w=$vals[0]";?>" rel="thumbnail" title="<?php the_title(); ?>"><?php echo"$vals[0] x $vals[1]";?></a></li><?
        }
        ?><li><a href="<?php echo $photo; ?>" rel="thumbnail" title="<?php the_title(); ?>"><?php _e('original size', 'wpzoom');?></a></li></ul>
        <div class="cleaner">&nbsp;</div>
        </div>
        <div class="sep">&nbsp;</div> <?php } // if dynamic sizes ?>
        <img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $photo; ?>&amp;h=<?php if ($type == 'wide'){echo"680"; } else {echo"440"; } ?>&amp;w=<?php if ($type == 'wide'){echo"910"; } else {echo"590"; } ?>&amp;zc=1" alt="<?php the_title(); ?>" class="preview" />
        <?php } // if $photo ?>
        <?php the_content(''); ?>
				<?php wp_link_pages(array('before' => '<p class="pages tabs">'.__('Pages', 'wpzoom').': ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
        <?php the_tags( '<p class="tags">'.__('Tags', 'wpzoom').': ', ', ', '</p>'); ?>
				</div><!-- end div.inside -->
        <?php if ($wpzoom_authors_show == 'Yes') {?>
        <div class="postauthor">
        <div class="avatar"><?php echo get_avatar( get_the_author_id() , 80 ); ?></div>
        <p class="more"><?php _e('More posts by', 'wpzoom');?> <?php the_author_posts_link(); ?> &raquo;</p>
        <h6><?php _e('Author', 'wpzoom');?>: <a href="<?php the_author_url(); ?>"><?php the_author_firstname(); the_author_lastname(); ?></a></h6>
        <p><?php the_author_description(); ?></p>
        <div class="cleaner">&nbsp;</div>
        </div>
        <?php } ?>
				<div class="sep">&nbsp;</div>
        <div class="share">
          <h4><?php _e('Share this Post', 'wpzoom');?></h4>
                 <ul>
                    <li><a href="http://twitter.com/share?url=<?php echo urlencode(the_permalink()); ?>&amp;text=<?php echo urlencode(the_title()); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/ic_twitter.png" alt="Tweet This!" /></a></li>
                    <li><a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink();?>&amp;title=<?php the_title_attribute();?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/ic_digg.png" alt="Digg it!" /></a></li>
                    <li><a href="http://del.icio.us/post?v=4&amp;noui&amp;jump=close&amp;url=<?php the_permalink();?>&amp;title=<?php the_title_attribute();?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/ic_delicious.png" alt="Add to Delicious!" /></a></li>
                    <li><a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/ic_facebook.png" alt="Share on Facebook!" /></a></li>
                    <li><a href="http://reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php the_title_attribute();?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/ic_reddit.png" alt="Share on Reddit!" /></a></li>
                    <li><a href="http://www.stumbleupon.com/submit?url=<?php the_permalink(); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/ic_stumbleupon.png" alt="Stumble it" /></a></li>
                    <li><a href="http://www.technorati.com/faves?add=<?php the_permalink(); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/ic_technorati.png" alt="Add to Technorati Favorites" /></a></li>
                    <li class="last"><a href="<?php if (strlen($wpzoom_misc_feedburner) < 10) { bloginfo('rss2_url');} else {echo"$wpzoom_misc_feedburner";} ?>" rel="external,nofollow"><img src="<?php bloginfo('template_directory'); ?>/images/ic_rss.png" alt="Subscribe by RSS" /></a></li>
                 </ul>
        </div>
<div class="cleaner">&nbsp;</div>
<?php if (strlen($wpzoom_ad_content_imgpath) > 1 && $wpzoom_ad_content_select == 'Yes' && $wpzoom_ad_content_pos == 'After') { echo '<div class="sep">&nbsp;</div><div class="banner">'.stripslashes($wpzoom_ad_content_imgpath)."</div>"; }?>
  <div class="sep">&nbsp;</div>
  <div class="comments">
    	<?php comments_template(); ?>
  </div>
	<?php endwhile; else: ?>

		<p><?php _e('Sorry, no posts matched your criteria.', 'wpzoom');?></p>
<?php endif; ?>

</div></div>

          </div><!-- end #posts -->
        </div><!-- end #content -->
<?php if ($showsidebar) { get_sidebar(); } ?>
<?php get_footer(); ?>
