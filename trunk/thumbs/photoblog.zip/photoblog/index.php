<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');
?>
<?php get_header(); ?>

        <div id="content">
          <div id="posts">
  
<?php if ( $paged < 2) { ?>
<?php include(TEMPLATEPATH . '/featured.php'); // calling featured section
} ?>

  
  <?php $z = count($wpzoom_exclude_cats_home);
      if ($z > 0)
      {
        $x = 0;
        $que = "";
        while ($x < $z)
        {
          $que .= "-".$wpzoom_exclude_cats_home[$x];
          $x++;
          if ($x < $z) {$que .= ",";}
        }
      }
      
      query_posts($query_string . "&cat=$que");
  
 include(TEMPLATEPATH . '/wpzoom_recent_posts.php'); ?>

          </div><!-- end #posts -->
        </div><!-- end #content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
