<?php 
/*
Template Name: Left Sidebar
*/
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
?>
<?php get_header(); ?>

        <div id="content" class="leftSidebar">

          <div id="single" class="singleP">

      <div class="block post">
      <div class="frame">
<?php wp_reset_query(); 
  if (have_posts()) : while (have_posts()) : the_post(); ?>
    <h1><?php the_title(); ?></h1>
    <p class="postmetadata"><?php edit_post_link( __('Edit', 'wpzoom'), '', ''); ?></p>
        <?php the_content(''); ?>
				<?php wp_link_pages(array('before' => '<p><strong>'.__('Pages', 'wpzoom').':</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>

		<div class="cleaner">&nbsp;</div>

    <div class="sep">&nbsp;</div>

    <div class="comments">
    <?php comments_template(); ?>
    </div>
		
    <?php endwhile; endif; ?>
  	

</div></div>

          </div><!-- end #posts -->
        </div><!-- end #content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>