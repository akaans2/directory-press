<?php 
  wp_reset_query(); 
    $featType = $wpzoom_featured_type;
          
          if ($featType == 'Tag')
          {
            $breaking_query = "tag=$wpzoom_featured_slug";  // Breaking tag slug
          }
          elseif ($featType == 'Category')
          {
            $breaking_query = "cat=$wpzoom_featured_slug";  // Breaking tag slug
          }

    $my_query = new WP_Query("showposts=$wpzoom_featured_num&$breaking_query&order_by=post_date&order=DESC");
    $i = 1;
    
?>
      <div id="featured">
        <!-- wrapper for navigator elements --> 
      <div id="loopedSlider">
        <div id="featMid">
         <a href="#" class="previous"><img src="<?php bloginfo('template_directory'); ?>/images/x.gif" width="36" height="58" class="prev" alt="" /></a><a href="#" class="next"><img src="<?php bloginfo('template_directory'); ?>/images/x.gif" width="36" height="58" class="next" alt="" /></a>
         <div class="container">          
          <div class="slides">
             <?php while ($my_query->have_posts()) : $my_query->the_post(); update_post_caches($posts); ?>
      <div class="slide">
      <div class="block post">
      <div class="frame">

<?php unset($img);
if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
						$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
            $img = $thumbURL[0]; 
						}

            else {
                unset($img);
                if ($wpzoom_cf_use == 'Yes')
                {
                  $img = get_post_meta($post->ID, $wpzoom_cf_photo, true);
                }
                else
                {
                  if (!$img)
                  {
                    $img = catch_that_image($post->ID);
                  }
                }
              }

         if ($img){ 
         $img = wpzoom_wpmu($img);
         ?>
        <div class="cover"><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=300&amp;w=590&amp;zc=1&amp;src=<?php echo $img ?>" alt="<?php the_title(); ?>" class="bordered" /></a></div><?php } ?>

        <div class="info"><h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
        <p class="postmetadata"><span class="category"><?php the_category(', '); ?></span> - <span class="timestamp"><?php the_time("M j, Y"); ?></span><?php edit_post_link( __('Edit', 'wpzoom'), ' | ', ''); ?></p>
        </div>
        <div class="cleaner">&nbsp;</div>
      </div>
      </div>
      </div>
             <?php endwhile; ?>
          </div><!-- end .slides -->
        </div><!-- end .container -->
        </div><!-- end #featMid -->
      </div><!-- end #loopedSlider -->
      </div><!-- end #featured -->
      <div class="cleaner">&nbsp;</div>
<?php wp_reset_query(); ?>