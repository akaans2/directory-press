<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');
?>
<?php get_header(); ?>

        <div id="content">
          <div id="posts">

	<?php 
  wp_reset_query();
  if (have_posts()) : ?>
<div class="block post">
      <div class="frame">
		<h1>Search Results for: <?php the_search_query(); ?></h1>
</div>
</div>

		<?php include(TEMPLATEPATH . '/wpzoom_recent_posts.php'); ?>
    <div class="navigation pagerbox">
			<?php next_posts_link(__('&laquo; Older Entries', 'wpzoom')); ?><?php previous_posts_link(__('Newer Entries &raquo;', 'wpzoom')); ?>
		</div>

	<?php else : ?>
<div class="block post">
      <div class="frame">
		<h1><?php _e('Search Results for', 'wpzoom');?>: <?php the_search_query(); ?></h1>
		<div class="cleaner">&nbsp;</div>
    <p>&nbsp;</p>
    <h3><?php _e('No posts found. Try a different search?', 'wpzoom');?></h3>
		</div>
		</div>

	<?php endif; ?>
          </div><!-- end #posts -->
        </div><!-- end #content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>