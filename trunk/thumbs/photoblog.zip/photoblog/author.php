<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');
?>
<?php get_header(); ?>

        <div id="content">
          <div id="posts">

<?php
		if(get_query_var('author_name')) :
		$curauth = get_userdatabylogin(get_query_var('author_name'));
		else :
		$curauth = get_userdata(get_query_var('author'));
		endif;
		?>

		<?php
  if (have_posts()) : ?>
<div class="block post">
      <div class="frame">
 	  <?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	  <?php /* If this is a category archive */ if (is_author()) { ?>
		<h1 class="pagetitle"><?php _e('Author Archive', 'wpzoom');?>: <a href="<?php echo $curauth->user_url; ?>"><?php echo $curauth->first_name; ?> <?php echo $curauth->last_name; ?></a></h1>
 	  <?php /* If this is a paged archive */ } ?>
 	  </div>
 	  </div>


		<?php include(TEMPLATEPATH . '/wpzoom_recent_posts.php'); ?>

	<?php else : ?>
<div class="block post">
      <div class="frame">
    <?
		if ( is_author() ) { // If this is a category archive
			$userdata = get_userdatabylogin(get_query_var('author_name'));
			printf('<h1>'.__('Sorry, but there aren\'t any posts by %s yet', 'wpzoom').'.</h1>', $userdata->display_name);
		} else {
			echo('<h1>'.__('No posts found', 'wpzoom').'.</h1>');
		}
    ?>
    <p>&nbsp;</p>
    <div class="cleaner"></div>
    </div>
    </div>
    <?php endif; ?>

          </div><!-- end #posts -->
        </div><!-- end #content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>