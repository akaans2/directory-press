		<?php while (have_posts()) : the_post(); ?>
<div class="block post">
      <div class="frame">

<?php unset($img);
if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
						$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
            $img = $thumbURL[0]; 
						}

            else {
                unset($img);
                if ($wpzoom_cf_use == 'Yes')
                {
                  $img = get_post_meta($post->ID, $wpzoom_cf_photo, true);
                }
                else
                {
                  if (!$img)
                  {
                    $img = catch_that_image($post->ID);
                  }
                }
              }

         if ($img){ 
         $img = wpzoom_wpmu($img);
         ?>
        <div class="cover"><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?h=300&amp;w=590&amp;zc=1&amp;src=<?php echo $img ?>" alt="<?php the_title(); ?>" class="bordered" /></a></div><?php } ?>

        <div class="info"><h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
        <p class="postmetadata"><span class="category"><?php the_category(', '); ?></span> - <span class="timestamp"><?php the_time("M j, Y"); ?></span><?php edit_post_link( __('Edit', 'wpzoom'), ' | ', ''); ?></p>
        </div>
        <div class="cleaner">&nbsp;</div>
      </div>
      </div>
  <?php endwhile; ?>
  
    <div class="navigation pagerbox">
			<?php next_posts_link(__('&laquo; Older Entries', 'wpzoom')); ?><?php previous_posts_link(__('Newer Entries &raquo;', 'wpzoom')); ?>
		</div>