<?php 
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
} 
$dateformat = get_option('date_format');
$timeformat = get_option('time_format');
$do_not_duplicate = array();

$type = get_post_meta($post->ID, "type", true);

$showsidebar = TRUE;
if ($type == 'wide')
{
  $addclass = " class=\"content-wide\"";
  $showsidebar = FALSE;
}
elseif ($type == 'leftsidebar')
{
  $addclass = " class=\"leftSidebar\"";
}

?>
<?php get_header(); ?>

        <div id="content"<?php echo"$addclass"; ?>>

          <div id="single" class="singleP">

      <div class="block post">
      <div class="frame">

  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div id="post-<?php the_ID(); ?>" class="inside">
			<h1><a href="<?php echo get_permalink($post->post_parent); ?>" rev="attachment"><?php echo get_the_title($post->post_parent); ?></a> &raquo; <?php the_title(); ?></h1>
				<div class="sep">&nbsp;</div>
				<a href="<?php echo wp_get_attachment_url($post->ID); ?>"><?php echo wp_get_attachment_image( $post->ID, 'medium' ); ?></a>
				<div class="caption"><?php if ( !empty($post->post_excerpt) ) the_excerpt(); // this is the "caption" ?></div>

				<?php the_content('<p class="serif">'.__('Read the rest of this entry', 'wpzoom').' &raquo;</p>'); ?>
		</div>

  <div class="sep">&nbsp;</div>
  <div class="comments">
    	<?php comments_template(); ?>
  </div>

	<?php endwhile; else: ?>

		<p><?php _e('Sorry, no posts matched your criteria.', 'wpzoom');?></p>
<?php endif; ?>

</div></div>

          </div><!-- end #posts -->
        </div><!-- end #content -->
<?php if ($showsidebar) { get_sidebar(); } ?>
<?php get_footer(); ?>